/*
 * chunk_operations.c
 *
 *  Created on: Oct 12, 2022
 *      Author: HP
 */

#include <kern/trap/fault_handler.h>
#include <kern/disk/pagefile_manager.h>
#include "kheap.h"
#include "memory_manager.h"
/******************************/
/*[1] RAM CHUNKS MANIPULATION */
/******************************/

//===============================
// 1) CUT-PASTE PAGES IN RAM:
//===============================
//This function should cut-paste the given number of pages from source_va to dest_va
//if the page table at any destination page in the range is not exist, it should create it
//Hint: use ROUNDDOWN/ROUNDUP macros to align the addresses
int cut_paste_pages(uint32* page_directory, uint32 source_va, uint32 dest_va, uint32 num_of_pages) {
	//TODO: [PROJECT MS2] [CHUNK OPERATIONS] cut_paste_pages
	// Write your code here, remove the panic and write your code
	//panic("cut_paste_pages() is not implemented yet...!!");
	dest_va = ROUNDDOWN(dest_va, 4*1024);
	source_va = ROUNDDOWN(source_va, 4*1024);
	uint32 * ptr_page_table_source;
	uint32 * ptr_page_table_dest;
	uint32 temp_dest = dest_va;
	for (int i = 0; i < num_of_pages; i++) {
		int ret2 = get_page_table(page_directory, temp_dest, &ptr_page_table_dest);
		if (ret2 == TABLE_IN_MEMORY) {
			if (ptr_page_table_dest[PTX(temp_dest)] != 0) {
				return -1;
			}
		}
		temp_dest += (4*1024);
	}
	for (int i = 0; i < num_of_pages; i++) {
		get_page_table(page_directory, source_va, &ptr_page_table_source);
		int ret2 = get_page_table(page_directory, dest_va, &ptr_page_table_dest);
		if (ret2 == TABLE_NOT_EXIST)
			create_page_table(page_directory, dest_va);
		struct FrameInfo * frame = get_frame_info(page_directory, source_va,&ptr_page_table_source);
		int perm = ptr_page_table_source[PTX(source_va)];
		perm&=4095;
		map_frame(page_directory, frame, dest_va, perm);
		frame->va = dest_va;
		unmap_frame(page_directory, source_va);
		dest_va += (4*1024);
		source_va += (4*1024);
	}
	return 0;
}

//===============================
// 2) COPY-PASTE RANGE IN RAM:
//===============================
//This function should copy-paste the given size from source_va to dest_va
//if the page table at any destination page in the range is not exist, it should create it
//Hint: use ROUNDDOWN/ROUNDUP macros to align the addresses
int copy_paste_chunk(uint32* page_directory, uint32 source_va, uint32 dest_va,uint32 size) {
	//TODO: [PROJECT MS2] [CHUNK OPERATIONS] copy_paste_chunk
	// Write your code here, remove the panic and write your code
//	panic("copy_paste_chunk() is not implemented yet...!!");
	int lastdestva = ROUNDDOWN(dest_va,4096) + size;
	int td = ROUNDDOWN(dest_va,4096);   //4096 = 4<<10
	int ts = ROUNDDOWN(source_va,4096);
	int dpgindx = PTX(td);    //dest pg index
	int spgindx = PTX(ts);  //source pg index
	uint32 *dpage_ptr = NULL;
	uint32 *spage_ptr = NULL;
	get_page_table(page_directory, source_va, &spage_ptr); //getting the source page content
	for(;td<lastdestva;td=td+4096)
	{
		dpgindx= PTX(td);
		if (get_page_table(page_directory, td, &dpage_ptr)== TABLE_IN_MEMORY)
		{
			if (dpage_ptr[dpgindx] != 0) {
				if((dpage_ptr[dpgindx] & PERM_WRITEABLE) == 0 )
				{
					return -1;
				}
			}
		}
	}
	struct FrameInfo *dframe_info_ptr = NULL;
	uint32 destvat = ROUNDDOWN(dest_va, 4096);
	uint32 srcvat = ROUNDDOWN(source_va, 4096);
	int perms = PERM_WRITEABLE;
	td= ROUNDDOWN(dest_va,4096);
	ts=ROUNDDOWN(source_va,4096);
	int ret=0;
	uint32 *ptr_page_table=NULL;
	while(td<lastdestva){    //int i=dest_va;i< lastdestva;i+4096
		get_page_table(page_directory,ts,&spage_ptr);
		spgindx = PTX(ts);
		perms = PERM_WRITEABLE;
		if((spage_ptr[spgindx] & PERM_USER )== PERM_USER)
		{
			perms = PERM_WRITEABLE | PERM_USER;
		}
		dframe_info_ptr = get_frame_info(page_directory, td,&ptr_page_table);
		if(ptr_page_table==NULL){
			create_page_table(page_directory, td);
		}
		if(dframe_info_ptr ==NULL){
			allocate_frame(&dframe_info_ptr);
		}
		map_frame(page_directory,dframe_info_ptr,td,perms);
		dframe_info_ptr->va = td;
		td=td+4096;
		ts=ts+4096;
	}
	char * s = (char *) (source_va);
	char * d = (char *) (dest_va);
	for (uint32 j = 0; j < size; j++) {
		d[j] = s[j];
	}
	return 0;

}

//===============================
// 3) SHARE RANGE IN RAM:
//===============================
//This function should share the given size from dest_va with the source_va
//Hint: use ROUNDDOWN/ROUNDUP macros to align the addresses
int share_chunk(uint32* page_directory, uint32 source_va, uint32 dest_va, uint32 size, uint32 perms) {
	//TODO: [PROJECT MS2] [CHUNK OPERATIONS] share_chunk
	// Write your code here, remove the panic and write your code
//	panic("share_chunk() is not implemented yet...!!");
	uint32 end_dest = dest_va +size;
	dest_va = ROUNDDOWN(dest_va, (4*1024));
	source_va = ROUNDDOWN(source_va, (4*1024));
	uint32 * ptr_page_table_source;
	uint32 * ptr_page_table_dest;
	uint32 ddest = dest_va;
	while(ddest< end_dest ){
		int ret2 = get_page_table(page_directory, ddest, &ptr_page_table_dest);
		if (ret2 == TABLE_IN_MEMORY) {
			if (ptr_page_table_dest[PTX(ddest)] != 0) {
				return -1;
			}
		}
		ddest += (4*1024);
	}
	while(dest_va< end_dest ){
		int ret2 = get_page_table(page_directory, dest_va, &ptr_page_table_dest);
		if (ret2 == TABLE_NOT_EXIST)
			create_page_table(page_directory, dest_va);
		struct FrameInfo * frame = get_frame_info(page_directory, source_va, &ptr_page_table_source);
		map_frame(page_directory, frame, dest_va, perms);
		source_va += (4*1024);
		dest_va += (4*1024);
	}
	return 0;

}

//===============================
// 4) ALLOCATE CHUNK IN RAM:
//===============================
//This function should allocate in RAM the given range [va, va+size)
//Hint: use ROUNDDOWN/ROUNDUP macros to align the addresses
int allocate_chunk(uint32* page_directory, uint32 va, uint32 size, uint32 perms) {
	//TODO: [PROJECT MS2] [CHUNK OPERATIONS] allocate_chunk
	// Write your code here, remove the panic and write your code
	// panic("allocate_chunk() is not implemented yet...!!");
	uint32 end =va+size;
	va =ROUNDDOWN(va, 4*1024);
	uint32 * ptr_page_table;
	uint32 temp_va = va;
	while (temp_va < end) {
		struct FrameInfo * frame = get_frame_info(page_directory, temp_va,&ptr_page_table);
		if (frame != NULL) {
			return -1;
		}
		temp_va += (4*1024);
	}
	while (va < end) {
		int ret2 = get_page_table(page_directory, va, &ptr_page_table);
		if (ret2 != TABLE_IN_MEMORY) {
			create_page_table(page_directory, va);
		}
		struct FrameInfo * new_frame = NULL;
		allocate_frame(&new_frame);
		map_frame(page_directory, new_frame, va, perms);
		new_frame->va = va;
		va += (4*1024);
	}
	return 0;


}

/*BONUS*/
//=====================================
// 5) CALCULATE ALLOCATED SPACE IN RAM:
//=====================================
void calculate_allocated_space(uint32* page_directory, uint32 sva, uint32 eva,
		uint32 *num_tables, uint32 *num_pages) {
	//TODO: [PROJECT MS2 - BONUS] [CHUNK OPERATIONS] calculate_allocated_space
	// Write your code here, remove the panic and write your code
//	panic("calculate_allocated_space() is not implemented yet...!!");
	sva = ROUNDDOWN(sva, (4*1024));
	uint32 * ptr_page_table = NULL;
	uint32 * temp = NULL;
	int c_num_tables = 0;
	int c_num_pages = 0;
	for (; sva < eva; sva += (4*1024)) {
		int ret2 = get_page_table(page_directory, sva, &ptr_page_table);
		if (ret2 == TABLE_IN_MEMORY) {
			if (ptr_page_table != temp) {
				c_num_tables++;
			}
			if (ptr_page_table[PTX(sva)] != 0) {
				c_num_pages++;
			}
		}
		temp = ptr_page_table;
	}
	*num_tables = c_num_tables;
	*num_pages = c_num_pages;
}

/*BONUS*/
//=====================================
// 6) CALCULATE REQUIRED FRAMES IN RAM:
//=====================================
// calculate_required_frames:
// calculates the new allocation size required for given address+size,
// we are not interested in knowing if pages or tables actually exist in memory or the page file,
// we are interested in knowing whether they are allocated or not.
uint32 calculate_required_frames(uint32* page_directory, uint32 sva,
		uint32 size) {
	//TODO: [PROJECT MS2 - BONUS] [CHUNK OPERATIONS] calculate_required_frames
	// Write your code here, remove the panic and write your code
//	panic("calculate_required_frames() is not implemented yet...!!");
	uint32 * ptr_page_table = NULL;
	uint32 eva =sva+size;
	sva =ROUNDDOWN(sva, 4*1024);
	uint32 last_Dir =-1;
	uint32 x =0;
	while(sva<eva){
		int ret2 = get_page_table(page_directory, sva, &ptr_page_table);
		if (ret2 == TABLE_IN_MEMORY) {
			if (ptr_page_table[PTX(sva)] == 0) {
					x++;
			}
		}
		else{
			x++;
			if(last_Dir!=(sva>>22))
				x++;
		}
		last_Dir=sva>>22;
		sva+=4*1024;
	}
	return x;
}
//=================================================================================//
//===========================END RAM CHUNKS MANIPULATION ==========================//
//=================================================================================//

/*******************************/
/*[2] USER CHUNKS MANIPULATION */
/*******************************/

//======================================================
/// functions used for USER HEAP (malloc, free, ...)
//======================================================
//=====================================
// 1) ALLOCATE USER MEMORY:
//=====================================
void allocate_user_mem(struct Env* e, uint32 virtual_address, uint32 size) {
	// Write your code here, remove the panic and write your code
	panic("allocate_user_mem() is not implemented yet...!!");
}

//=====================================
// 2) FREE USER MEMORY:
//=====================================
//bool tableIsEmpaty(uint32 * ptr_page_table){
//	for(int i =0 ;i< 1024;i++){
//		if(ptr_page_table[PTX(i)]!=0){
//			return 0;
//		}
//	}
//	return 1;
//}
void free_user_mem(struct Env* e, uint32 virtual_address, uint32 size) {
	//TODO: [PROJECT MS3] [USER HEAP - KERNEL SIDE] free_user_mem
	// Write your code here, remove the panic and write your code
//	panic("free_user_mem() is not implemented yet...!!");
	virtual_address = ROUNDDOWN(virtual_address , 4*1024);
	uint32 *ptr_page_table = NULL;
	int table_size = (1024*(4*1024));
	int page_size = 4*1024;

	int c = 0;
	uint32 va = 0;
	int start = ROUNDDOWN(virtual_address , table_size);
	int end = ROUNDUP(virtual_address+size , table_size );
	for(int i = start ; i<end ; i = i + table_size )
	{
		get_page_table(e->env_page_directory , i , &ptr_page_table);
		if(ptr_page_table !=NULL)
		{
			c = 0 ;
			for(uint32 k = i ; k < (i + table_size) ; k = k + page_size)
			{
				if(k >= virtual_address && k < (virtual_address+size)){
					pf_remove_env_page(e , k);
					unmap_frame(e->env_page_directory , k);
				}
				int table_entry = ptr_page_table[PTX(k)];
				if(table_entry == 0)
					c++;

			}
			if(c == 1024)
			{
				kfree(ptr_page_table);
				e->env_page_directory[PDX(i)] = 0;
			}

		}

	}
	for(int i= 0;i<e->page_WS_max_size;i++){
		va = e->ptr_pageWorkingSet[i].virtual_address;
		if(va >= virtual_address && va < (virtual_address+size)){
			env_page_ws_clear_entry(e, i);
		}
	}
	//This function should:
	//1. Free ALL pages of the given range from the Page File
	//2. Free ONLY pages that are resident in the working set from the memory
	//3. Removes ONLY the empty page tables (i.e. not used) (no pages are mapped in the table)
}

//=====================================
// 2) FREE USER MEMORY (BUFFERING):
//=====================================

void __free_user_mem_with_buffering(struct Env* e, uint32 virtual_address,
		uint32 size) {
	// your code is here, remove the panic and write your code
	panic("__free_user_mem_with_buffering() is not implemented yet...!!");

	//This function should:
	//1. Free ALL pages of the given range from the Page File
	//2. Free ONLY pages that are resident in the working set from the memory
	//3. Free any BUFFERED pages in the given range
	//4. Removes ONLY the empty page tables (i.e. not used) (no pages are mapped in the table)
}

//=====================================
// 3) MOVE USER MEMORY:
//=====================================
void move_user_mem(struct Env* e, uint32 src_virtual_address,
		uint32 dst_virtual_address, uint32 size) {
	//TODO: [PROJECT MS3 - BONUS] [USER HEAP - KERNEL SIDE] move_user_mem
	//your code is here, remove the panic and write your code
	panic("move_user_mem() is not implemented yet...!!");

	// This function should move all pages from "src_virtual_address" to "dst_virtual_address"
	// with the given size
	// After finished, the src_virtual_address must no longer be accessed/exist in either page file
	// or main memory

	/**/
}

//=================================================================================//
//========================== END USER CHUNKS MANIPULATION =========================//
//=================================================================================//

