#include "kheap.h"

#include <inc/memlayout.h>
#include <inc/dynamic_allocator.h>
#include "memory_manager.h"

//==================================================================//
//==================================================================//
//NOTE: All kernel heap allocations are multiples of PAGE_SIZE (4KB)//
//==================================================================//
//==================================================================//

void initialize_dyn_block_system()
{
	//TODO: [PROJECT MS2] [KERNEL HEAP] initialize_dyn_block_system
	// your code is here, remove the panic and write your code
//	kpanic_into_prompt("initialize_dyn_block_system() is not implemented yet...!!");

	 LIST_INIT(&AllocMemBlocksList);
	 LIST_INIT(&FreeMemBlocksList);
	//[1] Initialize two lists (AllocMemBlocksList & FreeMemBlocksList) [Hint: use LIST_INIT()]
#if STATIC_MEMBLOCK_ALLOC
	//DO NOTHING
#else
	 MAX_MEM_BLOCK_CNT = (KERNEL_HEAP_MAX - KERNEL_HEAP_START)/(4096);
	 int size_block = sizeof(struct MemBlock);
	 allocate_chunk(ptr_page_directory,KERNEL_HEAP_START,MAX_MEM_BLOCK_CNT*size_block,3);
	 MemBlockNodes =  (struct MemBlock *)KERNEL_HEAP_START;
	/*[2] Dynamically allocate the array of MemBlockNodes
	 * 	remember to:
	 * 		1. set MAX_MEM_BLOCK_CNT with the chosen size of the array
	 * 		2. allocation should be aligned on PAGE boundary
	 * 	HINT: can use alloc_chunk(...) function
	 */
	 initialize_MemBlocksList(MAX_MEM_BLOCK_CNT);
	 struct MemBlock *b = LIST_FIRST(&AvailableMemBlocksList);
	 b->sva =KERNEL_HEAP_START + ROUNDUP(MAX_MEM_BLOCK_CNT*size_block,4*1024);
	 b->size =KERNEL_HEAP_MAX -KERNEL_HEAP_START - ROUNDUP(MAX_MEM_BLOCK_CNT*size_block,4*1024);
	 LIST_REMOVE(&AvailableMemBlocksList,b);
	 insert_sorted_with_merge_freeList(b);
#endif
	//[3] Initialize AvailableMemBlocksList by filling it with the MemBlockNodes
	//[4] Insert a new MemBlock with the remaining heap size into the FreeMemBlocksList

}

void* kmalloc(unsigned int size)
{
	//TODO: [PROJECT MS2] [KERNEL HEAP] kmalloc
	// your code is here, remove the panic and write your code
//	kpanic_into_prompt("kmalloc() is not implemented yet...!!");
	size = ROUNDUP(size,4096);
	struct FrameInfo* frameinfoptr;
	struct MemBlock *allocated = NULL;
	if(isKHeapPlacementStrategyFIRSTFIT() == 1)  //# if FF
	{
		allocated = alloc_block_FF(size);
	}else if (isKHeapPlacementStrategyBESTFIT() == 1) 	//# if BF
	{
		allocated = alloc_block_BF(size);
	}else if (isKHeapPlacementStrategyNEXTFIT() == 1) //# if NF:
	{
		allocated = alloc_block_NF(size);
	}
	if (allocated == NULL) return NULL;
	int va = allocated->sva;
	int lastva = va + allocated->size;
	while(va<lastva)
	{
		allocate_frame(&frameinfoptr);
		map_frame( ptr_page_directory, frameinfoptr,va,PERM_WRITEABLE);
		frameinfoptr->va =va;
		va= va+4096;
	}
	insert_sorted_allocList(allocated);
	//change this "return" according to your answer
	return (void*)allocated->sva;

//	//NOTE: All kernel heap allocations are multiples of PAGE_SIZE (4KB)
//	//refer to the project presentation and documentation for details
//	// use "isKHeapPlacementStrategyFIRSTFIT() ..." functions to check the current strategy
//
//	//change this "return" according to your answer

}

void kfree(void* virtual_address)
{
	//TODO: [PROJECT MS2] [KERNEL HEAP] kfree
	// Write your code here, remove the panic and write your code
//	panic("kfree() is not implemented yet...!!");
	uint32 va = (uint32)virtual_address;
	va = ROUNDDOWN(va,4096);
	struct MemBlock * b = find_block(&AllocMemBlocksList,va);
	if(b == NULL)
		return;
	uint32 end = va+b->size;
	while(va < end){
		unmap_frame(ptr_page_directory,va);
		va+=(4*1024);
	}
	LIST_REMOVE(&AllocMemBlocksList,b);
	insert_sorted_with_merge_freeList(b);
}

unsigned int kheap_virtual_address(unsigned int physical_address)
{
	//TODO: [PROJECT MS2] [KERNEL HEAP] kheap_virtual_address
	// Write your code here, remove the panic and write your code
//	panic("kheap_virtual_address() is not implemented yet...!!");
	physical_address = ROUNDDOWN(physical_address,4*1024);
	struct FrameInfo *ptr_frame_info ;
	ptr_frame_info = to_frame_info(physical_address);
	if(ptr_frame_info!=NULL){
		if(ptr_frame_info->references!=0){
			return ptr_frame_info->va;
		}
	}
	return 0;
	//return the virtual address corresponding to given physical_address
	//refer to the project presentation and documentation for details
	//EFFICIENT IMPLEMENTATION ~O(1) IS REQUIRED ==================
}

unsigned int kheap_physical_address(unsigned int virtual_address)
{
	//TODO: [PROJECT MS2] [KERNEL HEAP] kheap_physical_address
	// Write your code here, remove the panic and write your code
//	panic("kheap_physical_address() is not implemented yet...!!");
	virtual_address = ROUNDDOWN(virtual_address,4*1024);
	uint32 *ptr_page_table = NULL;
	int ret = get_page_table(ptr_page_directory, virtual_address, &ptr_page_table);
	if (ret == TABLE_IN_MEMORY) {
		int x =  ptr_page_table[PTX(virtual_address)];
		x= x>>12;
		x= x<<12;
		return x ;
	}
	return -1;
	//return the physical address corresponding to given virtual_address
	//refer to the project presentation and documentation for details
}


void kfreeall()
{
	panic("Not implemented!");

}

void kshrink(uint32 newSize)
{
	panic("Not implemented!");
}

void kexpand(uint32 newSize)
{
	panic("Not implemented!");
}




//=================================================================================//
//============================== BONUS FUNCTION ===================================//
//=================================================================================//
// krealloc():

//	Attempts to resize the allocated space at "virtual_address" to "new_size" bytes,
//	possibly moving it in the heap.
//	If successful, returns the new virtual_address, in which case the old virtual_address must no longer be accessed.
//	On failure, returns a null pointer, and the old virtual_address remains valid.

//	A call with virtual_address = null is equivalent to kmalloc().
//	A call with new_size = zero is equivalent to kfree().

void *krealloc(void *virtual_address, uint32 new_size)
{
	//TODO: [PROJECT MS2 - BONUS] [KERNEL HEAP] krealloc
	// Write your code here, remove the panic and write your code
//	panic("krealloc() is not implemented yet...!!");
	uint32 va = (uint32)virtual_address;
	va = ROUNDDOWN(va,4*1024);
	new_size = ROUNDUP(new_size,4*1024);
	if(virtual_address == NULL ){
		return kmalloc(new_size);
	}
	else if(new_size == 0){
		kfree(virtual_address);
	}
	else{
		struct MemBlock *current_block = find_block(&AllocMemBlocksList , va);
		uint32 diff_size = (new_size - current_block->size);
		if(current_block->size>=new_size){
			return (void*)current_block->sva;
		}
		struct MemBlock * free= find_block(&FreeMemBlocksList,va+ current_block->size);
		if(free!=NULL){
			if(free->size ==diff_size){
				LIST_REMOVE(&FreeMemBlocksList,free);
				int re = allocate_chunk(ptr_page_directory,free->sva,diff_size ,3);
				if(re==0){
					free->size = 0;
					free->sva = 0;
					LIST_INSERT_HEAD(&AvailableMemBlocksList,free);
					current_block->size = new_size;
					return (void*)current_block->sva;
				}
			}
			else if(free->size > diff_size){
				int re = allocate_chunk(ptr_page_directory,free->sva,diff_size,3);
				if(re==0){
					free->size = free->size - diff_size;
					free->sva = free->sva + diff_size;
					current_block->size = new_size;
					return (void*)current_block->sva;
				}
			}
		}
		uint32 sva_allo= (uint32)kmalloc(new_size);
		if(sva_allo!=0){
			uint32 source_va = current_block->sva;
			uint32 dest_va = sva_allo;
			uint32 * ptr_page_table_source;
			while(source_va < (current_block->sva + current_block->size)) {
				struct FrameInfo * frame = get_frame_info(ptr_page_directory, source_va,&ptr_page_table_source);
				int perm = ptr_page_table_source[PTX(source_va)];
				perm&=4095;
				map_frame(ptr_page_directory, frame, dest_va, perm);
				frame->va = dest_va;
				unmap_frame(ptr_page_directory, source_va);
				dest_va += (4 << 10);
				source_va += (4 << 10);
			}
			LIST_REMOVE(&AllocMemBlocksList,current_block);
			insert_sorted_with_merge_freeList(current_block);
			return (void*)sva_allo;
		}
	}
	return NULL;
}
