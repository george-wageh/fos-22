/*
 * dyn_block_management.c
 *
 *  Created on: Sep 21, 2022
 *      Author: HP
 */
#include <inc/assert.h>
#include <inc/string.h>
#include "../inc/dynamic_allocator.h"

struct MemBlock* lastalloblock = NULL; //to save the location last allocated memory block
//==================================================================================//
//============================== GIVEN FUNCTIONS ===================================//
//==================================================================================//

//===========================
// PRINT MEM BLOCK LISTS:
//===========================

void print_mem_block_lists() {
	cprintf("\n=========================================\n");
	struct MemBlock* blk;
	struct MemBlock* lastBlk = NULL;
	cprintf("\nFreeMemBlocksList:\n");
	uint8 sorted = 1;
	LIST_FOREACH(blk, &FreeMemBlocksList)
	{
		if (lastBlk && blk->sva < lastBlk->sva + lastBlk->size)
			sorted = 0;
		cprintf("[%x, %x)-->", blk->sva, blk->sva + blk->size);
		lastBlk = blk;
	}
	if (!sorted)
		cprintf("\nFreeMemBlocksList is NOT SORTED!!\n");

	lastBlk = NULL;
	cprintf("\nAllocMemBlocksList:\n");
	sorted = 1;
	LIST_FOREACH(blk, &AllocMemBlocksList)
	{
		if (lastBlk && blk->sva < lastBlk->sva + lastBlk->size)
			sorted = 0;
		cprintf("[%x, %x)-->", blk->sva, blk->sva + blk->size);
		lastBlk = blk;
	}
	if (!sorted)
		cprintf("\nAllocMemBlocksList is NOT SORTED!!\n");
	cprintf("\n=========================================\n");
}

//********************************************************************************//
//********************************************************************************//

//==================================================================================//
//============================ REQUIRED FUNCTIONS ==================================//
//==================================================================================//

//===============================
// [1] INITIALIZE AVAILABLE LIST:
//===============================
void initialize_MemBlocksList(uint32 numOfBlocks) {
	//TODO: [PROJECT MS1] [DYNAMIC ALLOCATOR] initialize_MemBlocksList
	// Write your code here, remove the panic and write your code
	//panic("initialize_MemBlocksList() is not implemented yet...!!");
	LIST_INIT(&AvailableMemBlocksList);
	for (int i = 0; i < numOfBlocks; i++) {
		struct MemBlock *ptr = &(MemBlockNodes[i]);
		ptr->size = 0;
		ptr->sva = 0;
		LIST_INSERT_TAIL(&AvailableMemBlocksList, ptr);
	}

}

//===============================
// [2] FIND BLOCK:
//===============================
struct MemBlock *find_block(struct MemBlock_List *blockList, uint32 va) {
	//TODO: [PROJECT MS1] [DYNAMIC ALLOCATOR] find_block
	// Write your code here, remove the panic and write your code
	//panic("find_block() is not implemented yet...!!");
	struct MemBlock *it = NULL;
	LIST_FOREACH(it,blockList)
	{
		if (it->sva == va)
			return it;
	}
	return NULL;

}

//=========================================
// [3] INSERT BLOCK IN ALLOC LIST [SORTED]:
//=========================================
void insert_sorted_allocList(struct MemBlock *blockToInsert) {
	//TODO: [PROJECT MS1] [DYNAMIC ALLOCATOR] insert_sorted_allocList
	// Write your code here, remove the panic and write your code
	//panic("insert_sorted_allocList() is not implemented yet...!!");
	if (LIST_EMPTY(&AllocMemBlocksList)) {
		LIST_INSERT_HEAD(&AllocMemBlocksList, blockToInsert);
	} else if (LIST_FIRST(&AllocMemBlocksList)->sva > blockToInsert->sva) {
		LIST_INSERT_HEAD(&AllocMemBlocksList, blockToInsert);
	} else {
		struct MemBlock* it = NULL;
		struct MemBlock* next = NULL;
		LIST_FOREACH(it,&AllocMemBlocksList)
		{
			next = LIST_NEXT(it);
			if (next != NULL) {
				if (it->sva < blockToInsert->sva) {
					if ((next->sva > blockToInsert->sva)) {
						LIST_INSERT_AFTER(&AllocMemBlocksList, it,
								blockToInsert);
						return;
					}
				}
			} else {
				LIST_INSERT_AFTER(&AllocMemBlocksList, it, blockToInsert);
				return;
			}
		}
	}

}

//=========================================
// [4] ALLOCATE BLOCK BY FIRST FIT:
//=========================================
struct MemBlock *alloc_block_FF(uint32 size) {
	//TODO: [PROJECT MS1] [DYNAMIC ALLOCATOR] alloc_block_FF
	// Write your code here, remove the panic and write your code
	//panic("alloc_block_FF() is not implemented yet...!!");
	struct MemBlock *it = NULL;
	LIST_FOREACH( it, &FreeMemBlocksList)
	{
		if (size == it->size) {
			LIST_REMOVE(&FreeMemBlocksList, it);
			return it;
		} else if (size < it->size) {
			struct MemBlock * newBlock = LIST_FIRST(&AvailableMemBlocksList);
			LIST_REMOVE(&AvailableMemBlocksList, newBlock);
			newBlock->size = size;
			newBlock->sva = it->sva;
			it->size = (it->size) - size;
			it->sva = it->sva + size;
			return newBlock;
		}

	}
	return NULL;
}

//=========================================
// [5] ALLOCATE BLOCK BY BEST FIT:
//=========================================
struct MemBlock *alloc_block_BF(uint32 size) {
	//TODO: [PROJECT MS1] [DYNAMIC ALLOCATOR] alloc_block_BF
	// Write your code here, remove the panic and write your code
	//panic("alloc_block_BF() is not implemented yet...!!");
	struct MemBlock *it = NULL;
	struct MemBlock *it2 = NULL;
	LIST_FOREACH(it , &FreeMemBlocksList)
	{
		if (size == it->size) {
			LIST_REMOVE(&FreeMemBlocksList, it);
			return it;
		} else if (size < it->size) {
			if (it2 == NULL) {
				it2 = it;
			} else if (it2->size > it->size) {
				it2 = it;
			}
		}

	}
	if (it2 != NULL) {
		struct MemBlock * newBlock = LIST_FIRST(&AvailableMemBlocksList);
		newBlock->size = size;
		newBlock->sva = it2->sva;
		LIST_REMOVE(&AvailableMemBlocksList, newBlock);
		it2->size = (it2->size) - size;
		it2->sva = it2->sva + size;
		return newBlock;
	} else {
		return NULL;
	}

}

//=========================================
// [7] ALLOCATE BLOCK BY NEXT FIT:
//=========================================
struct MemBlock *alloc_block_NF(uint32 size) {
	//TODO: [PROJECT MS1 - BONUS] [DYNAMIC ALLOCATOR] alloc_block_NF
	// Write your code here, remove the panic and write your code
	//panic("alloc_block_NF() is not implemented yet...!!");
	struct MemBlock * found = NULL;
	if (LIST_EMPTY(&FreeMemBlocksList))
		return NULL;
	if (lastalloblock == NULL)
		lastalloblock = LIST_FIRST(&FreeMemBlocksList);
	else{
		struct MemBlock *iterator=NULL;
		if(lastalloblock!=NULL){
			LIST_FOREACH(iterator,&FreeMemBlocksList){
				if(iterator->sva > lastalloblock->sva ){
					if((size <= iterator->size)){
						found = iterator;
						break;
					}
				}
			}
		}
	}
	struct MemBlock *it = LIST_FIRST(&FreeMemBlocksList);
	if(found!=NULL){
		it = found;
	}
	while (it !=NULL) {
		if (size == it->size) {
			lastalloblock = it; //saving last allocated block
			LIST_REMOVE(&FreeMemBlocksList, it);
			return it;
		} else if (size < it->size) {
			struct MemBlock* newBlock = LIST_FIRST(&AvailableMemBlocksList);
			LIST_REMOVE(&AvailableMemBlocksList, newBlock);
			newBlock->size = size;
			newBlock->sva = it->sva;
			it->size = it->size - size;
			it->sva = it->sva + size;
			lastalloblock = newBlock; //saving last allocated block
			return newBlock;
		}
		it = LIST_NEXT(it);
	}
	return NULL;
}

//===================================================
// [8] INSERT BLOCK (SORTED WITH MERGE) IN FREE LIST:
//===================================================
void insert_sorted_with_merge_freeList(struct MemBlock *blockToInsert) {
//	cprintf(
//			"BEFORE INSERT with MERGE: insert [%x, %x)\n=====================\n",
//			blockToInsert->sva, blockToInsert->sva + blockToInsert->size);
//	print_mem_block_lists();

	//TODO: [PROJECT MS1] [DYNAMIC ALLOCATOR] insert_sorted_with_merge_freeList
	// Write your code here, remove the panic and write your code
	//panic("insert_sorted_with_merge_freeList() is not implemented yet...!!");
	if(lastalloblock == blockToInsert){
		lastalloblock = NULL;
	}
	struct MemBlock* it = NULL;
	struct MemBlock* next = NULL;
	bool merge = 0;
	if (LIST_EMPTY(&FreeMemBlocksList)) {
		LIST_INSERT_HEAD(&FreeMemBlocksList, blockToInsert);
	} else if (LIST_FIRST(&FreeMemBlocksList)->sva > blockToInsert->sva) {
		merge = 1;
		LIST_INSERT_HEAD(&FreeMemBlocksList, blockToInsert);
		it = blockToInsert;
	} else {
		LIST_FOREACH(it,&FreeMemBlocksList)
		{
			next = it->prev_next_info.le_next;
			if (it->sva < blockToInsert->sva) {
				if (next == NULL) {
					LIST_INSERT_AFTER(&FreeMemBlocksList, it, blockToInsert);
					merge = 1;
					break;
				} else {
					if ((next->sva > blockToInsert->sva)) {
						LIST_INSERT_AFTER(&FreeMemBlocksList, it,
								blockToInsert);
						merge = 1;
						break;
					}
				}
			}
		}
	}
	if (merge) {
		for (int i = 0; i < 2; i++) {
			next = LIST_NEXT(it);
			if (next == NULL)
				break;
			if (((it->size) + (it->sva)) == next->sva) {
				next->size += it->size;
				next->sva = it->sva;
				LIST_REMOVE(&FreeMemBlocksList, it);
				it->size = 0;
				it->sva = 0;
				LIST_INSERT_HEAD(&AvailableMemBlocksList, it);
			}
			it = next;
		}
	}
//	cprintf("\nAFTER INSERT with MERGE:\n=====================\n");
//	print_mem_block_lists();

}

