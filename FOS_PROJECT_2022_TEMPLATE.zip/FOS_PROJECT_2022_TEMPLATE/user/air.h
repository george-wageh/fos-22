/*
 * air.h
 *
 *  Created on: May 25, 2013
 *      Author: os
 */

#ifndef AIR_H_
#define AIR_H_

struct Customer
{
	int flightType;
	int booked;
};
#endif /* AIR_H_ */
